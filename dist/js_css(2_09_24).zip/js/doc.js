console.log('doc')
//# sourceMappingURL=doc.js.map